//join
//Channel : https://t.me/saqibnadir123
//Group : https://t.me/snmodder
bool Esp, EspLine;
#include "PlayerSearcher.h"
#define libName OBFUSCATE("libcocos2dcpp.so")

int iii;

struct CCPoint 
{
    float x;
    float y;  
    CCPoint() : x(0), y(0) {}
    CCPoint(float _x, float _y) : x(_x), y(_y) 
    {
        
    }
    CCPoint(const CCPoint& other) : x(other.x), y(other.y) 
    {
        
    }
    ~CCPoint() 
    {
        
    }
    CCPoint& operator=(const CCPoint& other) 
    {
        if (this != &other) 
        {
            x = other.x;
            y = other.y;
        }
        return *this;
    }
};

#include "Canvas/ESP.h"

int screenW = 0;
int screenH = 0;

Vector2 (*getBodyPosition)(void *);
void *(*getParent)(void *);
Vector2 (*convertToWorldSpace)(void *, Vector2);
Vector2 (*getPosition)(void *node);
Vector2 (*convertToUI)(void *, Vector2 ss);


Vector2 getWorldBodyPos(void* player) {
    void* node = static_cast<void*>(player);
    Vector2 localPos = getBodyPosition(player);
    void* parentNode = getParent(node);
    if (parentNode) {
        return convertToWorldSpace(parentNode, localPos);
    } else {
        return localPos;
    }
}


Vector2 WorldToScreen(Vector2 worldPos)
{
    return Vector2(worldPos.X, screenH - worldPos.Y);
}



void (*old_SoldierController)(void *thiz, float t);
void _SoldierController(void *thiz, float t) {
     if (thiz != nullptr) {
       
          iii++;
         
             if (!playerFind(thiz)) players.push_back(thiz);
             if (players.size() > 50) {
                 players.clear();
             }
                    
     }
     return old_SoldierController(thiz, t);
}



