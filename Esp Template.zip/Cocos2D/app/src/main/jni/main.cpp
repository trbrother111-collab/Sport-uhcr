#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>

#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"

#include "Menu/Register.h"
#include "Canvas/Color.h"
#include "hooks.h"

#include <Substrate/SubstrateHook.h>
#include <Substrate/CydiaSubstrate.h>

ESP espOverlay;





void DrawESP(ESP esp, int screenWidth, int screenHeight) {
   
    screenW = screenWidth;
    screenH = screenHeight;
    
    std::string count;
    count += "Players : ";
    count += std::to_string(players.size());
    esp.DrawText(Color(0,0,0,255), count.c_str(), Vector2(screenWidth / 2, screenHeight / 8), 65.0f); 

    
    //if (Esp) {
         string pussy;
         for (int i = 0; i < players.size(); i++) {
               auto Player = players[i];
                 if (Player != nullptr) {
                     
                     Vector2 BodyPos = WorldToScreen(getWorldBodyPos(Player)); 
                     Vector2 From = Vector2(screenWidth / 2, screenHeight / 8.8);
                    
                     //Vector2 pos = getPosition(Player);

                     esp.DrawLine(Color(255, 0, 0, 255), 2.0f, From, BodyPos);               
              
       }
    }
 
}







void *hack_thread(void *) {
    do {
        sleep(1);
    } while (!isLibraryLoaded(libName));
       
    
    MSHookFunction((void *)getAbsoluteAddress(libName, 0x00574ba0), (void *)&_SoldierController, (void **)&old_SoldierController); 
    getBodyPosition = (Vector2 (*)(void *))getAbsoluteAddress(libName, 0x00577770);
    getParent = (void *(*)(void *))getAbsoluteAddress(libName, 0x0063fafc);
    convertToWorldSpace = (Vector2 (*)(void *, Vector2))getAbsoluteAddress(libName, 0x00641208);
    getPosition = (Vector2 (*)(void *))getAbsoluteAddress(libName, 0x0063f734);  
    
    return NULL;
}







jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Category_ESP"),//Not counted
            
            
            
    };

    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

void Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {
    switch (featNum) {
   
        case 0: Esp = boolean; break;
        case 1: EspLine = boolean; break;
        
        
    }
}

__attribute__((constructor))
void lib_main() {
 
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_android_support_Menu_DrawOn(JNIEnv *env, jclass type, jobject espView, jobject canvas) {
    espOverlay = ESP(env, espView, canvas);
    if (espOverlay.isValid()) {
        DrawESP(espOverlay, espOverlay.getWidth(), espOverlay.getHeight());
    }
}

extern "C"
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;

    vm->GetEnv((void **) &env, JNI_VERSION_1_6);

    static const JNINativeMethod menuMethods[] = {
            {OBFUSCATE("Icon"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
            {OBFUSCATE("IconWebViewData"),  OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(IconWebViewData)},
            {OBFUSCATE("IsGameLibLoaded"),  OBFUSCATE("()Z"), reinterpret_cast<void *>(isGameLibLoaded)},
            {OBFUSCATE("Init"),  OBFUSCATE("(Landroid/content/Context;Landroid/widget/TextView;Landroid/widget/TextView;)V"), reinterpret_cast<void *>(Init)},
            {OBFUSCATE("GetFeatureList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList)},
    };

    if (Register(env, "com/android/support/Menu", menuMethods, sizeof(menuMethods) / sizeof(JNINativeMethod)) != 0)
        return JNI_ERR;

    static const JNINativeMethod prefMethods[] = {
            { OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IZLjava/lang/String;)V"), reinterpret_cast<void *>(Changes)},
    };

    if (Register(env, "com/android/support/Preferences",
                 prefMethods, sizeof(prefMethods) / sizeof(JNINativeMethod)) != 0)
        return JNI_ERR;

    static const JNINativeMethod mainMethods[] = {
            { OBFUSCATE("CheckOverlayPermission"), OBFUSCATE("(Landroid/content/Context;)V"), reinterpret_cast<void *>(CheckOverlayPermission)},
    };

    if (Register(env, "com/android/support/Main", mainMethods, sizeof(mainMethods) / sizeof(JNINativeMethod)) != 0)
        return JNI_ERR;

    return JNI_VERSION_1_6;
}
